package com.hostmdy.uni.repository;

import org.springframework.data.repository.CrudRepository;

import com.hostmdy.uni.domain.Teacher;

public interface TeacherRepository extends CrudRepository<Teacher, Long>{

}

package com.hostmdy.uni;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SpringUniversityManagementAppApplication {

	public static void main(String[] args) {
		SpringApplication.run(SpringUniversityManagementAppApplication.class, args);
	}

}

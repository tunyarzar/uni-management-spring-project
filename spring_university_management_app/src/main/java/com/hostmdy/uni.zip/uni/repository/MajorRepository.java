package com.hostmdy.uni.repository;

import org.springframework.data.repository.CrudRepository;

import com.hostmdy.uni.domain.Major;


public interface MajorRepository extends CrudRepository<Major, Long>{

}
